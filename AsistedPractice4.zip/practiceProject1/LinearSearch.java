package practiceProject1;

class Linear{
	public void search(int arr[],int value) {
		int i;
		for(i=0;i<arr.length;i++) {
			if(arr[i]==value){
				System.out.println("Value found at "+i+" index");
				break;
			}
		}
		if(i==arr.length) {
			System.out.println("value Not found");
		}
	}
}

public class LinearSearch {
	public static void main(String[] args) {
		Linear linear = new Linear();
		int arr[] = new int[] {5,3,1,6,8,9,2,4};
		linear.search(arr,6);
	}
}
