public class Demo {
    public static void main (String [] args){
        System.out.println("This is my the 1st java program purely written by me");
    }
}
