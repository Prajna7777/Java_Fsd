package practise_Project4;

public class ParaConstructorMain {
    public static void main(String[] args) {
		// ParaConstructor p = new ParaConstructor(100,7700);
        new ParaConstructor(100, 7700); // Creating an instance without assigning to a variable

	}
}
