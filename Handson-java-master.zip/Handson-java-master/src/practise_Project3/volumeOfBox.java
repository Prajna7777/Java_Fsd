package practise_Project3;
// example of method execution, declaration
public class volumeOfBox {
    double display(double length,double breadth,double height) {
		return length*breadth*height;
	}

}
