package practiseProject1;

//Creation of thread by extending Thread class
public class ThreadCreation extends Thread{
	
	public void run()
	{
		System.out.println("thread started running");
	}
	
	public static void main(String[] args) {
		ThreadCreation th = new ThreadCreation();
		//calling start method
		th.start();
	}
}
