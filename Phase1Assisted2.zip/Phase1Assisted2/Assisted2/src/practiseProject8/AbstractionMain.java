package practiseProject8;

class CalcImpl extends AbstractionEx {

    @Override
    public void sum(int val1, int val2) {
        System.out.println("Sum is " + (val1 + val2));
    }

    @Override
    public void sub(int val1, int val2) {
        System.out.println("Sub is " + (val1 - val2));
    }
}

public class AbstractionMain {

    public static void main(String[] args) {
        CalcImpl cc = new CalcImpl();
        cc.sum(100, 234);
        cc.sub(108, 73);
    }
}
