package practiseProject4;

import java.util.Scanner;

public class TryCatchDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter two numbers for division:");

        try {
            System.out.print("Enter numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter denominator: ");
            int denominator = scanner.nextInt();

            // Attempt to perform division
            int result = divide(numerator, denominator);

            // Display the result
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            // This block will always be executed, regardless of whether an exception occurred or not
            System.out.println("Finally block executed");
            scanner.close();
        }
    }

    // Method to perform division (may throw ArithmeticException)
    private static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }
}

