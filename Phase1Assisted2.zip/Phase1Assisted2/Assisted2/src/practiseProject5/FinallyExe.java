package practiseProject5;

import java.util.Scanner;

public class FinallyExe {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            int arr[] = new int[4];
            System.out.println("Enter elements to add in array ");
            
            for (int i = 0; i < 5; i++) {
                int val = sc.nextInt();
                arr[i] = val;
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            // Ensure that the Scanner is closed
            sc.close();
            System.out.println("Thank You !!!");
        }
    }
}
