package practiseProject5;

import java.util.Scanner;

class ThrowKeyword {

    static void checkRoll(int x) {
        try {
            if (x < 0) {
                throw new NumberFormatException("Negative value entered for roll number");
            } else {
                System.out.println("Congratulations! Your roll number is verified.");
            }
        } catch (NumberFormatException ex) {
            System.out.println("Exception: " + ex.getMessage());
            System.out.println("Please enter a positive number for the roll number.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter roll number:");
            int rollNumber = sc.nextInt();
            checkRoll(rollNumber);
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
