package practiseProject6;

public class ExceptionHandling {
    public static void main(String[] args) {

		try {
			int b[]= {2,3,4,5,67};
			b[12]=24;
		}

		catch (ArrayIndexOutOfBoundsException e) {

			e.printStackTrace();
		}
		finally {
			System.out.println("Thank you !!");
		}
	}
}
